// Registration
document.getElementById('registerForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    try {
        const response = await fetch('/register', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: new URLSearchParams(formData)
        });

        if (response.ok) {
            window.location.href = '/login';
        } else {
            alert(await response.text());
        }
    } catch (error) {
        alert('Registration failed');
    }
});

// Login
document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    try {
        const response = await fetch('/login', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: new URLSearchParams(formData)
        });

        if (response.ok) {
            window.location.href = '/home';
        } else {
            alert(await response.text());
        }
    } catch (error) {
        alert('Login failed');
    }
});

// Embed Page
document.getElementById('imageInput')?.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('image', file);

    try {
        const response = await fetch('/capacity', {
            method: 'POST',
            body: formData
        });
        const data = await response.json();

        if (response.ok) {
            document.getElementById('capacityValue').textContent = data.capacity;
            document.getElementById('capacityInfo').classList.remove('hidden');
        } else {
            alert('Error: ' + data.error);
        }
    } catch (error) {
        alert('Capacity check failed');
    }
});

document.getElementById('embedForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    try {
        const response = await fetch('/embed', {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'secret.png';
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
        } else {
            alert(await response.text());
        }
    } catch (error) {
        alert('Embedding failed');
    }
});

// Extract Page
document.getElementById('extractForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    try {
        const response = await fetch('/extract', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();

        if (response.ok) {
            document.getElementById('messageContent').textContent = result.message;
            document.getElementById('result').classList.remove('hidden');
        } else {
            alert(result.error || 'Extraction failed');
        }
    } catch (error) {
        alert('Extraction failed');
    }
});